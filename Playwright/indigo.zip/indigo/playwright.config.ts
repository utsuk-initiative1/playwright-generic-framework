import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
        testDir: './tests',
  fullyParallel: true,
  forbidOnly: false,
  retries: 2,
  workers: process.env.CI ? 1 : undefined,
  
  reporter: [
    ['html', { outputFolder: 'playwright-report' }],
    ['json', { outputFile: 'test-results/results.json' }],
    ['list']
  ],

  use: {
    baseURL: 'https://cloud.indigo-uat.waldodgws.com/',
    // Enhanced tracing and video recording for better debugging
    trace: 'retain-on-failure', // Keep traces for failed tests
    screenshot: 'only-on-failure', // Screenshots on failure
    video: 'retain-on-failure', // Keep videos for failed tests
    headless: false,
    viewport: { width: 1920, height: 1080 },
    actionTimeout: 30000,
    navigationTimeout: 30000,
  },

  projects: [
    {
      name: 'chromium',
      use: { 
        ...devices['Desktop Chrome'],
        // Enhanced video recording for Chromium
        video: { mode: 'retain-on-failure', size: { width: 1920, height: 1080 } }
      },
    },
    {
      name: 'firefox',
      use: { 
        ...devices['Desktop Firefox'],
        video: { mode: 'retain-on-failure', size: { width: 1920, height: 1080 } }
      },
    },
    {
      name: 'webkit',
      use: { 
        ...devices['Desktop Safari'],
        video: { mode: 'retain-on-failure', size: { width: 1920, height: 1080 } }
      },
    },
  ],

  outputDir: 'test-results/',
  timeout: 30000,
  expect: {
    timeout: 10000,
  },
});