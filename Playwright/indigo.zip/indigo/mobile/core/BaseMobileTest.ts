import { test as base, expect, Page } from '@playwright/test';
import { BaseMobilePage } from '../core/BaseMobilePage';
import { EmulatorManager } from '../utils/EmulatorManager';

// Extend the test type with mobile-specific fixtures
export const test = base.extend<{
  mobilePage: BaseMobilePage;
  emulatorManager: EmulatorManager;
}>({
  emulatorManager: async ({}, use) => {
    const emulatorManager = new EmulatorManager();
    await use(emulatorManager);
  },

  mobilePage: async ({ page }, use) => {
    // This will be set by individual test classes
    await use({} as BaseMobilePage);
  }
});

export { expect };

export abstract class BaseMobileTest {
  protected page: Page;
  protected emulatorManager: EmulatorManager;

  constructor(page: Page, emulatorManager: EmulatorManager) {
    this.page = page;
    this.emulatorManager = emulatorManager;
  }

  // Setup and teardown methods
  async setupTest() {
    console.log('Setting up mobile test...');
    
    // Check if required tools are available
    if (process.platform === 'darwin') {
      const xcodeAvailable = await this.emulatorManager.checkXcode();
      if (!xcodeAvailable) {
        throw new Error('Xcode is required for iOS testing on macOS');
      }
    }

    const androidSDKAvailable = await this.emulatorManager.checkAndroidSDK();
    if (!androidSDKAvailable) {
      console.warn('Android SDK not found. Android testing will be limited.');
    }
  }

  async teardownTest() {
    console.log('Tearing down mobile test...');
    
    // Clean up resources
    await this.page.close();
  }

  // Emulator management
  async startAndroidEmulator(avdName: string): Promise<boolean> {
    return await this.emulatorManager.startAndroidEmulator(avdName);
  }

  async stopAndroidEmulator(): Promise<boolean> {
    return await this.emulatorManager.stopAndroidEmulator();
  }

  async startIOSSimulator(deviceName: string): Promise<boolean> {
    return await this.emulatorManager.startIOSSimulator(deviceName);
  }

  async stopIOSSimulator(): Promise<boolean> {
    return await this.emulatorManager.stopIOSSimulator();
  }

  // App management
  async installAndroidApp(apkPath: string): Promise<boolean> {
    return await this.emulatorManager.installAndroidApp(apkPath);
  }

  async launchAndroidApp(packageName: string, activityName?: string): Promise<boolean> {
    return await this.emulatorManager.launchAndroidApp(packageName, activityName);
  }

  async installIOSApp(appPath: string): Promise<boolean> {
    return await this.emulatorManager.installIOSApp(appPath);
  }

  async launchIOSApp(bundleId: string): Promise<boolean> {
    return await this.emulatorManager.launchIOSApp(bundleId);
  }

  // Test utilities
  async waitForAppLoad(timeout: number = 10000) {
    await this.page.waitForLoadState('networkidle', { timeout });
  }

  async takeScreenshot(name: string) {
    await this.page.screenshot({ path: `test-results/${name}.png` });
  }

  async recordVideo(name: string) {
    // Video recording implementation
    console.log('Recording video:', name);
  }

  // Performance testing
  async measurePerformance(metric: string): Promise<number> {
    return await this.page.evaluate((metric) => {
      switch (metric) {
        case 'loadTime':
          return performance.timing.loadEventEnd - performance.timing.navigationStart;
        case 'domContentLoaded':
          return performance.timing.domContentLoadedEventEnd - performance.timing.navigationStart;
        case 'firstPaint':
          return performance.getEntriesByType('paint')[0]?.startTime || 0;
        default:
          return 0;
      }
    }, metric);
  }

  // Error handling
  async handleTestError(error: Error, context: string) {
    console.error(`Test error in ${context}:`, error.message);
    await this.takeScreenshot(`error_${context}_${Date.now()}`);
    
    // Log additional information
    const deviceInfo = await this.page.evaluate(() => ({
      userAgent: navigator.userAgent,
      platform: navigator.platform,
      screenSize: { width: screen.width, height: screen.height }
    }));
    
    console.log('Device info at error:', deviceInfo);
    throw error;
  }
}