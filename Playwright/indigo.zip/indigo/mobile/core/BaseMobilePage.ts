import { Page, Locator } from '@playwright/test';
import { MobileGestures } from '../utils/MobileGestures';
import { MobileInteractions } from '../utils/MobileInteractions';

export abstract class BaseMobilePage {
  protected page: Page;
  protected gestures: MobileGestures;
  protected interactions: MobileInteractions;

  constructor(page: Page) {
    this.page = page;
    this.gestures = new MobileGestures(page);
    this.interactions = new MobileInteractions(page);
  }

  // Abstract methods that must be implemented by child classes
  abstract getPageUrl(): string;
  abstract waitForPageLoad(): Promise<void>;

  // Common mobile page methods
  async navigateTo(url?: string) {
    const targetUrl = url || this.getPageUrl();
    await this.page.goto(targetUrl);
    await this.waitForPageLoad();
  }

  async waitForElement(selector: string, timeout: number = 5000) {
    await this.page.waitForSelector(selector, { timeout });
  }

  async isElementVisible(selector: string): Promise<boolean> {
    return await this.page.isVisible(selector);
  }

  async tapElement(selector: string) {
    await this.interactions.tapElement(selector);
  }

  async typeText(selector: string, text: string) {
    await this.interactions.typeText(selector, text);
  }

  async getText(selector: string): Promise<string> {
    return await this.interactions.getText(selector);
  }

  async scrollToElement(selector: string) {
    await this.page.scrollIntoViewIfNeeded(selector);
  }

  async takeScreenshot(name: string) {
    await this.page.screenshot({ path: `screenshots/${name}.png` });
  }

  // Device orientation
  async setOrientation(orientation: 'portrait' | 'landscape') {
    await this.gestures.orientation(orientation);
  }

  // App lifecycle
  async launchApp(appPath: string) {
    await this.interactions.launchApp(appPath);
  }

  async closeApp() {
    await this.interactions.closeApp();
  }

  // Network and permissions
  async enableWifi() {
    await this.interactions.enableWifi();
  }

  async disableWifi() {
    await this.interactions.disableWifi();
  }

  async enableLocation() {
    await this.interactions.enableLocation();
  }

  async disableLocation() {
    await this.interactions.disableLocation();
  }

  // Performance monitoring
  async getBatteryLevel(): Promise<number> {
    return await this.interactions.getBatteryLevel();
  }

  async getMemoryUsage(): Promise<number> {
    return await this.interactions.getMemoryUsage();
  }

  async getCPUUsage(): Promise<number> {
    return await this.interactions.getCPUUsage();
  }

  // Error handling
  async handleError(error: Error, context: string) {
    console.error(`Error in ${context}:`, error.message);
    await this.takeScreenshot(`error_${context}_${Date.now()}`);
    throw error;
  }
}