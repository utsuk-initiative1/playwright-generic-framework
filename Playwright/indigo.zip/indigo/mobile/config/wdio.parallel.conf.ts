export const parallelConfig = {
  runner: 'local',
  specs: [
    './tests/**/*.spec.ts'
  ],
  maxInstances: 2,
  capabilities: [
    // Android capability
    {
      platformName: 'Android',
      'appium:platformVersion': '13.0',
      'appium:deviceName': 'Android Emulator',
      'appium:automationName': 'UiAutomator2',
      'appium:app': process.env.ANDROID_APP_PATH || './apps/app-debug.apk'
    },
    // iOS capability
    {
      platformName: 'iOS',
      'appium:platformVersion': '16.0',
      'appium:deviceName': 'iPhone Simulator',
      'appium:automationName': 'XCUITest',
      'appium:app': process.env.IOS_APP_PATH || './apps/MyApp.app'
    }
  ],
  logLevel: 'info',
  bail: 0,
  baseUrl: 'http://localhost',
  waitforTimeout: 10000,
  connectionRetryTimeout: 120000,
  connectionRetryCount: 3,
  services: ['appium'],
  framework: 'mocha',
  reporters: ['spec'],
  mochaOpts: {
    ui: 'bdd',
    timeout: 60000
  }
};