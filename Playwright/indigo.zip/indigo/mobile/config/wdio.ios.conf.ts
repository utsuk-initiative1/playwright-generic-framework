export const iosConfig = {
  runner: 'local',
  specs: [
    './tests/**/*.spec.ts'
  ],
  maxInstances: 1,
  capabilities: [{
    platformName: 'iOS',
    'appium:platformVersion': '16.0',
    'appium:deviceName': 'iPhone Simulator',
    'appium:automationName': 'XCUITest',
    'appium:app': process.env.IOS_APP_PATH || './apps/MyApp.app',
    'appium:autoAcceptAlerts': true,
    'appium:noReset': false
  }],
  logLevel: 'info',
  bail: 0,
  baseUrl: 'http://localhost',
  waitforTimeout: 10000,
  connectionRetryTimeout: 120000,
  connectionRetryCount: 3,
  services: ['appium'],
  framework: 'mocha',
  reporters: ['spec'],
  mochaOpts: {
    ui: 'bdd',
    timeout: 60000
  }
};