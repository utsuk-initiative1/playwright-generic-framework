import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export class EmulatorManager {
  private androidSDKPath: string;
  private iosSimulatorPath: string;

  constructor() {
    this.androidSDKPath = process.env.ANDROID_HOME || '/usr/local/android-sdk';
    this.iosSimulatorPath = '/Applications/Xcode.app/Contents/Developer/Applications/Simulator.app';
  }

  // Android Emulator Management
  async startAndroidEmulator(avdName: string): Promise<boolean> {
    try {
      console.log('Starting Android emulator:', avdName);
      const { stdout } = await execAsync(`${this.androidSDKPath}/emulator/emulator -avd ${avdName} -no-snapshot-load`);
      console.log('Android emulator started successfully');
      return true;
    } catch (error) {
      console.error('Failed to start Android emulator:', error);
      return false;
    }
  }

  async stopAndroidEmulator(): Promise<boolean> {
    try {
      console.log('Stopping Android emulator');
      await execAsync('adb emu kill');
      console.log('Android emulator stopped successfully');
      return true;
    } catch (error) {
      console.error('Failed to stop Android emulator:', error);
      return false;
    }
  }

  async installAndroidApp(apkPath: string): Promise<boolean> {
    try {
      console.log('Installing Android app:', apkPath);
      await execAsync(`adb install ${apkPath}`);
      console.log('Android app installed successfully');
      return true;
    } catch (error) {
      console.error('Failed to install Android app:', error);
      return false;
    }
  }

  async launchAndroidApp(packageName: string, activityName?: string): Promise<boolean> {
    try {
      console.log('Launching Android app:', packageName);
      const command = activityName 
        ? `adb shell am start -n ${packageName}/${activityName}`
        : `adb shell monkey -p ${packageName} -c android.intent.category.LAUNCHER 1`;
      await execAsync(command);
      console.log('Android app launched successfully');
      return true;
    } catch (error) {
      console.error('Failed to launch Android app:', error);
      return false;
    }
  }

  async getAndroidEmulatorStatus(): Promise<string> {
    try {
      const { stdout } = await execAsync('adb devices');
      return stdout;
    } catch (error) {
      console.error('Failed to get Android emulator status:', error);
      return 'Unknown';
    }
  }

  // iOS Simulator Management
  async startIOSSimulator(deviceName: string): Promise<boolean> {
    try {
      console.log('Starting iOS simulator:', deviceName);
      await execAsync(`xcrun simctl boot ${deviceName}`);
      await execAsync(`open ${this.iosSimulatorPath}`);
      console.log('iOS simulator started successfully');
      return true;
    } catch (error) {
      console.error('Failed to start iOS simulator:', error);
      return false;
    }
  }

  async stopIOSSimulator(): Promise<boolean> {
    try {
      console.log('Stopping iOS simulator');
      await execAsync('xcrun simctl shutdown all');
      console.log('iOS simulator stopped successfully');
      return true;
    } catch (error) {
      console.error('Failed to stop iOS simulator:', error);
      return false;
    }
  }

  async installIOSApp(appPath: string): Promise<boolean> {
    try {
      console.log('Installing iOS app:', appPath);
      await execAsync(`xcrun simctl install booted ${appPath}`);
      console.log('iOS app installed successfully');
      return true;
    } catch (error) {
      console.error('Failed to install iOS app:', error);
      return false;
    }
  }

  async launchIOSApp(bundleId: string): Promise<boolean> {
    try {
      console.log('Launching iOS app:', bundleId);
      await execAsync(`xcrun simctl launch booted ${bundleId}`);
      console.log('iOS app launched successfully');
      return true;
    } catch (error) {
      console.error('Failed to launch iOS app:', error);
      return false;
    }
  }

  async getIOSSimulatorStatus(): Promise<string> {
    try {
      const { stdout } = await execAsync('xcrun simctl list devices');
      return stdout;
    } catch (error) {
      console.error('Failed to get iOS simulator status:', error);
      return 'Unknown';
    }
  }

  // Utility methods
  async checkAndroidSDK(): Promise<boolean> {
    try {
      await execAsync('adb version');
      return true;
    } catch (error) {
      console.error('Android SDK not found. Please install Android SDK and set ANDROID_HOME');
      return false;
    }
  }

  async checkXcode(): Promise<boolean> {
    try {
      await execAsync('xcrun --version');
      return true;
    } catch (error) {
      console.error('Xcode not found. Please install Xcode for iOS development');
      return false;
    }
  }

  async listAndroidEmulators(): Promise<string[]> {
    try {
      const { stdout } = await execAsync(`${this.androidSDKPath}/emulator/emulator -list-avds`);
      return stdout.trim().split('\n').filter(avd => avd.length > 0);
    } catch (error) {
      console.error('Failed to list Android emulators:', error);
      return [];
    }
  }

  async listIOSSimulators(): Promise<string[]> {
    try {
      const { stdout } = await execAsync('xcrun simctl list devices available');
      const lines = stdout.split('\n');
      return lines
        .filter(line => line.includes('iPhone') || line.includes('iPad'))
        .map(line => line.split('(')[0].trim());
    } catch (error) {
      console.error('Failed to list iOS simulators:', error);
      return [];
    }
  }
}