#!/bin/bash

echo "Mobile Emulator Setup Script"

# Function to check Android SDK
check_android_sdk() {
    if command -v adb &> /dev/null; then
        echo "Android SDK found"
        return 0
    else
        echo "Android SDK not found"
        return 1
    fi
}

# Function to check Xcode
check_xcode() {
    if command -v xcrun &> /dev/null; then
        echo "Xcode found"
        return 0
    else
        echo "Xcode not found"
        return 1
    fi
}

# Function to list Android emulators
list_android_emulators() {
    if check_android_sdk; then
        echo "Available Android Emulators:"
        emulator -list-avds
    fi
}

# Function to list iOS simulators
list_ios_simulators() {
    if check_xcode; then
        echo "Available iOS Simulators:"
        xcrun simctl list devices available | grep -E "(iPhone|iPad)"
    fi
}

# Function to start Android emulator
start_android_emulator() {
    local avd_name=$1
    if [ -z "$avd_name" ]; then
        echo "Please provide AVD name"
        return 1
    fi
    
    if check_android_sdk; then
        echo "Starting Android emulator: $avd_name"
        emulator -avd "$avd_name" -no-snapshot-load &
        echo "Android emulator started"
    fi
}

# Function to start iOS simulator
start_ios_simulator() {
    local device_name=$1
    if [ -z "$device_name" ]; then
        echo "Please provide device name"
        return 1
    fi
    
    if check_xcode; then
        echo "Starting iOS simulator: $device_name"
        xcrun simctl boot "$device_name"
        open -a Simulator
        echo "iOS simulator started"
    fi
}

# Main script
echo "Checking mobile development environment..."

# Check Android SDK
check_android_sdk

# Check Xcode (macOS only)
if [[ "$OSTYPE" == "darwin"* ]]; then
    check_xcode
fi

# List available emulators/simulators
echo ""
list_android_emulators
echo ""
list_ios_simulators

echo ""
echo "Usage:"
echo "  ./setup-emulator.sh android <avd_name>  - Start Android emulator"
echo "  ./setup-emulator.sh ios <device_name>   - Start iOS simulator"
echo "  ./setup-emulator.sh list                - List all available devices"