#!/bin/bash

echo "Setting up Mobile Automation Environment..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "Node.js is not installed. Please install Node.js first."
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "npm is not installed. Please install npm first."
    exit 1
fi

# Install dependencies
echo "Installing dependencies..."
npm install

# Install Appium globally
echo "Installing Appium..."
npm install -g appium

# Install Appium drivers
echo "Installing Appium drivers..."
appium driver install uiautomator2
appium driver install xcuitest

# Check Android SDK
if command -v adb &> /dev/null; then
    echo "Android SDK found"
else
    echo "Android SDK not found. Please install Android SDK and set ANDROID_HOME"
fi

# Check Xcode (macOS only)
if [[ "$OSTYPE" == "darwin"* ]]; then
    if command -v xcrun &> /dev/null; then
        echo "Xcode found"
    else
        echo "Xcode not found. Please install Xcode for iOS development"
    fi
fi

echo "Mobile automation environment setup completed!"
echo "You can now run your mobile tests!"